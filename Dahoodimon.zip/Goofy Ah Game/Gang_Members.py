Enemies = {
    "Tyrone": {
        "Name": 'Tyrone',
        'HP': 200,
        'dmg': 20,
    },
    "Doomsday Hong": {
        "Name": 'Doomsday Hong',
        'HP': 300,
        'dmg': 40,
    },
    "Steampunk Willie": {
        "Name": "Steampunk Willie",
        "HP": 500,
        "dmg": 45
    },
    "Steampunk Tyrone": {
        "Name": "Steampunk Tyrone",
        "HP": 600,
        "dmg": 60
    }
}