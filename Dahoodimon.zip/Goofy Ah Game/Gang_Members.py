Enemies = {
    "Tyrone": {
        "Name": 'Tyrone',
        'HP': 200,
        'dmg': 20,
    },
    "Doomsday Hong": {
        "Name": 'Doomsday Hong',
        'HP': 300,
        'dmg': 30,
    },
    "Steampunk Willie": {
        "Name": "Steampunk Willie",
        "HP": 500,
        "dmg": 45
    },
    "Steampunk Tyrone": {
        "Name": "Steampunk Tyrone",
        "HP": 600,
        "dmg": 60
    },
    "Puppet Tyrone": {
        "Name": "Puppet Tyrone",
        "HP": 60,
        "dmg": 0
    }
}